/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    int marks[6];
    int i, total = 0;
    float percentage;
    int above90 = 0;
    int between75_90 = 0;
    int between50_75 = 0;
    int below50 = 0;
    printf("Enter marks of 6 subjects\n");
    for (i = 0; i < 6; i++) {
        printf("Subject %d: ", i + 1);
        scanf("%d", &marks[i]);
        total += marks[i];
        if (marks[i] > 90) {
            above90++;
        } else if (marks[i] >= 75) {
            between75_90++;
        } else if (marks[i] >= 50) {
            between50_75++;
        } else {
            below50++;
        }
    }
    percentage = total / 6.0;
    char performance[30];
    if (percentage >= 90)
        printf( "Excellent");
    else if (percentage >= 80)
        printf( "Very Good");
    else if (percentage >= 70)
    printf( "Good");
    else if (percentage >= 50)
        printf( "Average");
    else
        printf( "Needs Improvement");
    printf(" STUDENT PERFORMANCE REPORT\n");
    printf("Total Marks: %d\n", total);
    printf("Percentage: %.2f%%\n", percentage);
    printf("\nSubject-wise Distribution:\n");
    printf(">90 Marks: %d subjects\n", above90);
    printf("75–90 Marks: %d subjects\n", between75_90);
    printf("50–75 Marks: %d subjects\n", between50_75);
    printf("<50 Marks: %d subjects\n", below50);

    return 0;
}