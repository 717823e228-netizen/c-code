/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int choice;
    float balance = 0, amount;

    do {
        printf("\n------ ATM MENU ------\n");
        printf("1. Deposit Money\n");
        printf("2. Withdraw Money\n");
        printf("3. Check Balance\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1:  // Deposit
                printf("Enter amount to deposit: ");
                scanf("%f", &amount);
                balance += amount;
                printf("Amount deposited successfully!\n");
                break;

            case 2:  // Withdraw
                printf("Enter amount to withdraw: ");
                scanf("%f", &amount);

                if(amount > balance) {
                    printf("Insufficient balance! Withdrawal denied.\n");
                } else {
                    balance -= amount;
                    printf("Withdrawal successful!\n");
                }
                break;

            case 3:  // Balance
                printf("Current Balance: %.2f\n", balance);
                break;

            case 4:  // Exit
                printf("Thank you! Exiting ATM.\n");
                break;

            default:
                printf("Invalid choice! Please try again.\n");
        }

    } while(choice != 4);  // run until user chooses Exit

    return 0;
}
