/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    float prices[5] = {120.0, 55.5, 30.0, 75.0, 200.0};
    int qty[5];
    float total = 0, discount = 0, discountedTotal, gst, finalAmount;
    int i;
    printf("MINI BILLING SYSTEM\n");
    printf("Enter quantity for each item\n");
    for (i = 0; i < 5; i++) {
        printf("Item %d (Price ₹%.2f): ", i + 1, prices[i]);
        scanf("%d", &qty[i]);
        total += qty[i] * prices[i];
    }
    if (total > 1000)
        discount = total * 0.10;   
    else if (total > 500)
        discount = total * 0.05;
    else
        discount = 0;
    discountedTotal = total - discount;
    gst = discountedTotal * 0.05;
    finalAmount = discountedTotal + gst;
    printf("BILL INVOICE\n");
    printf("Item\tQty\t Price\tSubtotal\n");
    for (i = 0; i < 5; i++) {
        printf("%d\t%d\t₹%.2f\t₹%.2f\n",
               i + 1, qty[i], prices[i], qty[i] * prices[i]);
    }
    printf("Total Before Discount: ₹%.2f\n", total);
    printf("Discount Applied: ₹%.2f\n", discount);
    printf("Amount After Discount: ₹%.2f\n", discountedTotal);
    printf("GST (5%%): ₹%.2f\n", gst);
    printf("FINAL BILL AMOUNT: ₹%.2f\n", finalAmount);
    return 0;
}