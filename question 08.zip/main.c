/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    int level;
    printf("Enter tank water level: ");
    scanf("%d",&level);
    if (level < 10) {
        printf("ALERT! Water level is low\n");
    }
    else if (level < 30) {
        printf("low\n");
        printf("Start filling the tank\n");
    }
    else if (level <= 70) {
        printf("medium\n");
        printf("Filling optional\n");
    }
    else {
        printf("high\n");
        printf("No need to fill the tank\n");
    }

    return 0;
}