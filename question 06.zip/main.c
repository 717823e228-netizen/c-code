/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {

    while(1) {   // repeat forever

        // RED signal (10 seconds)
        for(int i = 10; i >= 1; i--) {
            printf("RED : %d seconds\n", i);
        }

        // YELLOW signal (3 seconds)
        for(int i = 3; i >= 1; i--) {
            printf("YELLOW : %d seconds\n", i);
        }

        // GREEN signal (7 seconds)
        for(int i = 7; i >= 1; i--) {
            printf("GREEN : %d seconds\n", i);
        }

        printf("\n--- Cycle Repeating ---\n\n");
    }

    return 0;
}
