#include <stdio.h>
#include <string.h>

int main() {
    char mobile[50];
    int i;
    printf("Enter Mobile Number: ");
    scanf("%s", mobile);
    int len = strlen(mobile);
    if (len!=10) {
        printf("Invalid\n");
        return 0;
    }
    for (i = 0; i < len; i++) {
        if (mobile[i] < '0' || mobile[i] > '9') {
            printf("Invalid:Mobile number must contain only digits\n");
            return 0;
        }
    }
    if (mobile[0] == '0') {
        printf("mobile number should not start with 0\n");
        return 0;
    }
    printf("Valid Mobile Number\n");
    return 0;
}
