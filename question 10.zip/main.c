/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()

    {
    int hours, regularPay, overtimePay, totalPay;
    int weeklyTotal = 0;
    int i;
 printf("Employee Payroll Calculator\n");
   printf("\n");
 for(i=1;i<=7;i++)
 {
 printf("Enter working hours for Day %d: ", i);
 scanf("%d", &hours);

        if(hours <= 8) {
            regularPay = hours * 100;        
            overtimePay = 0;
        } else
        
{
            regularPay = 8 * 100;  
            overtimePay = (hours - 8) * (100 * 2); 
        }

        totalPay = regularPay + overtimePay;
        weeklyTotal += totalPay;
    }

    printf("\n Weekly Payroll Summary \n");
    printf("Total Weekly Salary: ₹%d\n", weeklyTotal);
    printf("\n");
    return 0;
}

