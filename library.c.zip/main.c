/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int days;
    int fine = 0;
    printf("Enter no.of.days overdue: ");
    scanf("%d",&days);
    if (days > 30) {
        printf("Membership Cancelled\n");
        return 0;
    }
    printf("\nFine Calculation Details:\n");
    if (days <= 5) {
        fine = days * 2;
        printf("Days 1–5: %d days × ₹2 = ₹%d\n", days, fine);
    } 
    else if (days <= 10) {
        int first = 5 * 2;
        int remaining = (days - 5) * 5;
        fine = first + remaining;

        printf("Days 1to5:5×2 = ₹%d\n", first);
        printf("Days 6to10:%d×5 = ₹%d\n", days - 5, remaining);
    }
    else {  
        int first = 5 * 2;
        int second = 5 * 5;
        int remaining = (days - 10) * 10;
        fine = first + second + remaining;

        printf("Days 1–5: 5 days × ₹2 = ₹%d\n", first);
        printf("Days 6–10: 5 days × ₹5 = ₹%d\n", second);
        printf("Days 11–%d: %d days × ₹10 = ₹%d\n", days, days-10, remaining);
    }
    printf("Total amount= ₹%d\n",fine);

    return 0;
}
