/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    char name[50];
    int age;
    float distance, price, finalPrice;
    printf("BUS TICKET RESERVATION\n");
    printf("Enter passenger name: ");
    fgets(name, sizeof(name), stdin);
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Enter travel distance: ");
    scanf("%f", &distance);
    price = distance * 3;  
    if (age < 5) {
        finalPrice = 0;
    } else if (age > 60) {
        finalPrice = price * 0.5; 
    } else {
        finalPrice = price;
    }
    printf("TICKET SLIP\n");
    printf("Passenger Name: %s", name);
    printf("Age: %d\n", age);
    printf("Distance: %f\n", distance);
    printf("Base Price: %.2f\n", price);
    printf("FINAL TICKET PRICE : %.2f\n", finalPrice);
    return 0;
}
