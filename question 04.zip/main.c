/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    float t[24], sum = 0;
    float max, min, avg;
    int maxHour = 0, minHour = 0;

    for(int i = 1; i < 24; i++) {
        printf("Enter temperature at hour %d: ", i);
        scanf("%f", &t[i]);
    }
    max = min = t[0];
    for(int i = 0; i < 24; i++) {
        sum += t[i];

        if(t[i] > max) {
            max = t[i];
            maxHour = i;
        }
        if(t[i] < min) {
            min = t[i];
            minHour = i;
        }
    }

    avg = sum / 24;
    printf("\nMax Temp = %.1f at Hour %d\n", max, maxHour);
    printf("Min Temp = %.1f at Hour %d\n", min, minHour);
    printf("Average Temp = %.1f\n", avg);
    if(avg >= 35)
        printf("Day is HOT\n");
    else if(avg >= 20)
        printf("Day is NORMAL\n");
    else
        printf("Day is COLD\n");

    return 0;
}
